import java.util.Scanner;
public class Calculator {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		//Let user choose their operation
		System.out.println("Menu:" 
							+ "\n 1. Addition"
							+ "\n 2. Subtraction"
							+ "\n 3. Multiplication"
							+ "\n 4. Division"
							+ "\n 5. Remainder");
		System.out.println("Choose your operation");
		int choose = keyboard.nextInt();
		//if the user did not input between 1 to 5 it will display unavailable.
		if (choose < 1 || choose > 5) {
			System.out.println("Unavailable, Please select a number between 1 to 5.");
		}
		else {
			System.out.println("Enter the first number");
			double num1 = keyboard.nextDouble();
		
			System.out.println("Enter the secound number");
			double num2 = keyboard.nextDouble();
		
			switch(choose) {
			case 1:
				System.out.println("Answer: " + (num1 + num2));
				break;
			case 2:
				System.out.println("Answer: " +(num1 - num2));
				break;
			case 3:
				System.out.println("Answer: " + (num1 * num2));
				break;
			case 4:
				if (num2 != 0) {
					System.out.println("Answer: "+ (num1 / num2));
				}
				else {
					System.out.println("Cannot divide by 0");
				}
				break;
			case 5:
				if (num2 != 0) {
					System.out.println("Answer:"+ (num1 % num2));
				}
				else {
					System.out.println("Cannot divide by 0");
			}
				break;
				default:
					System.out.println("Unavailable");
			}
		}
		keyboard.close();
	}

}
