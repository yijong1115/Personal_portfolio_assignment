import javax.swing.JOptionPane;

public class Car_Rental {
	public static void main(String[] args) {
		//Let user choose the type of car
		/**String[] declares that carTypes is an array of strings.
		*carTypes is the name of the array variable and this array contains three elements,which are the names of different types of cars Compact, Sedan, and SUV.
		*/
		String[] carTypes = {"Compact", "Sedan", "SUV"};
		String car;
		//(String) is use to cast the result of JOptionPane
        car = (String)JOptionPane.showInputDialog(null, "Select the type of car:", "Car Rental",
                JOptionPane.QUESTION_MESSAGE, null, carTypes, carTypes[0]);
        												// After String [], we can access  individual elements of the array using their index.
        												// For example carType[0] is Compact, carType[1] is Sedan and carType[3] is SUV.
        //Let user choose rental duration
        String[] rentalDurations = {"Daily", "Weekly 15% OFF!","Monthly 30% OFF!"};
        String duration;
        duration = (String)JOptionPane.showInputDialog(null, "Select the duration of rental:","Car Rental",
        		JOptionPane.QUESTION_MESSAGE, null, rentalDurations, rentalDurations[0]);
        //Base rental rates 
        double rate;
        switch (car) {
        case "Compact":
        	rate = 30.50;
        	break;
        case "Sedan":
        	rate = 50.00;
        	break;
        case "SUV":
        	rate = 80.96;
        	break;
        	default:
        		rate = 0.0;
        }
        	//Calculation
        double discountedRate;
        switch(duration) {
        case "Daily":
        	discountedRate = rate;
        	break;
        case "Weekly 15% OFF!":
        	discountedRate = rate * 0.85*7;
        	break;
        case "Monthly 30% OFF!":
        	discountedRate = rate * 0.70*30;
        	break;
        	default:
        		discountedRate = 0.0;
        }	
        	
        	JOptionPane.showMessageDialog(null,"Car Type: " + car + "\nRental Duration: " 
        	+ duration + "\nTotal Rental Cost: $" + String.format("%.2f", discountedRate),"Car Rental", JOptionPane.INFORMATION_MESSAGE);
        }														//convert double to string to change to two decimal point.
        
        
  }
	


